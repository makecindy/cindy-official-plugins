# @open-artifact/cli

The `open-artifact` command of [Open Artifact](https://github.com/JimLiu/open-artifact): slide decks, design canvases and whiteboards an agent
makes as folders of files, which you view, edit, comment on and export in one local page. Comments sent from the
page come back to the agent. Needs Node.js 22.18 or later.

```bash
npx @open-artifact/cli artifact '{"action":"list","scope":"types"}'   # the Artifact tool from the command line
npx @open-artifact/cli mcp --harness <name>                           # a stdio MCP server for an agent app
npx @open-artifact/cli daemon status
npx @open-artifact/cli help
```

It carries the daemon, the Shell and the built-in types, and starts the one local daemon when none runs. The same
folder is the `open-artifact` skill (`SKILL.md`); the plugins for Claude Code, Codex, Cursor, Copilot and
Antigravity carry it too. See the [repository](https://github.com/JimLiu/open-artifact) for them.
