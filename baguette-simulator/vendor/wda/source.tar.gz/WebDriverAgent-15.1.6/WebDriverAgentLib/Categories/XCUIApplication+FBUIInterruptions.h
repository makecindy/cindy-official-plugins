/**
 * Copyright (c) 2015-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree.
 */

#import <XCTest/XCTest.h>

NS_ASSUME_NONNULL_BEGIN

@interface XCUIApplication (FBUIInterruptions)

/**
 * Disables automatic UI interruptions handling for all applications.
 */
+ (void)fb_disableUIInterruptionsHandling;

@end

NS_ASSUME_NONNULL_END
